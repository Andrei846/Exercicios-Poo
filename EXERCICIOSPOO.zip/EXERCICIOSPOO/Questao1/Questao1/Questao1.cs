﻿using System;

class Aluno
{
    public int RA { get; set; }
    public string Nome { get; set; }
    public double NotaProva { get; set; }
    public double NotaTrabalho { get; set; }
    public double NotaFinal { get; set; }

    public void CalcularMedia()
    {
        NotaFinal = (NotaProva + NotaTrabalho) / 2;
    }

    public bool CalcularNotaFinal()
    {
        double notaNecessaria = 0;

        if (NotaFinal >= 6)
        {
            Console.WriteLine($"Aluno {Nome} aprovado com nota final de {NotaFinal:F2}.");
            return true;
        }
        else
        {
            notaNecessaria = 6 - NotaFinal;
            Console.WriteLine($"Aluno {Nome} reprovado. Precisa de {notaNecessaria:F2} na prova final.");
            return false;
        }
    }

    public void ImprimirNotaFinal()
    {
        Console.WriteLine($"A nota final de {Nome} é: {NotaFinal:F2}");
    }

    public void ReceberDados()
    {
        Console.Write("Digite o RA do aluno: ");
        RA = int.Parse(Console.ReadLine());

        Console.Write("Digite o nome do aluno: ");
        Nome = Console.ReadLine();

        Console.Write("Digite a nota da prova: ");
        NotaProva = double.Parse(Console.ReadLine());

        Console.Write("Digite a nota do trabalho: ");
        NotaTrabalho = double.Parse(Console.ReadLine());
    }
}

class Program
{
    static void Main(string[] args)
    {
        Aluno aluno = new Aluno();

        aluno.ReceberDados();

        aluno.CalcularMedia();

        aluno.CalcularNotaFinal();

        aluno.ImprimirNotaFinal();
    }
}
