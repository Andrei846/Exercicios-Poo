﻿using System;

class Lampada
{
    // Atributo para armazenar o estado da lâmpada
    public bool Ligada { get; private set; }

    // Método para ligar a lâmpada
    public void Ligar()
    {
        Ligada = true;
        Console.WriteLine("A lâmpada foi ligada.");
    }

    // Método para desligar a lâmpada
    public void Desligar()
    {
        Ligada = false;
        Console.WriteLine("A lâmpada foi desligada.");
    }

    // Método para mostrar o estado da lâmpada
    public void MostrarEstado()
    {
        if (Ligada)
        {
            Console.WriteLine("A lâmpada está ligada.");
        }
        else
        {
            Console.WriteLine("A lâmpada está desligada.");
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        // Criando um objeto Lampada
        Lampada lampada = new Lampada();

        bool continuar = true;

        // Menu interativo
        while (continuar)
        {
            Console.WriteLine("\nEscolha uma opção:");
            Console.WriteLine("1 - Ligar a lâmpada");
            Console.WriteLine("2 - Desligar a lâmpada");
            Console.WriteLine("3 - Mostrar estado da lâmpada");
            Console.WriteLine("4 - Sair");

            string opcao = Console.ReadLine();

            switch (opcao)
            {
                case "1":
                    lampada.Ligar();
                    break;

                case "2":
                    lampada.Desligar();
                    break;

                case "3":
                    lampada.MostrarEstado();
                    break;

                case "4":
                    Console.WriteLine("Saindo... Até logo!");
                    continuar = false;
                    break;

                default:
                    Console.WriteLine("Opção inválida! Tente novamente.");
                    break;
            }
        }
    }
}
